<?php
/**
 * Created by PhpStorm.
 * User: jiehua
 * Date: 15/5/2
 * Time: 下午6:21
 */

class SignData
{
    public $signSourceData = null;

    public $sign = null;

} 